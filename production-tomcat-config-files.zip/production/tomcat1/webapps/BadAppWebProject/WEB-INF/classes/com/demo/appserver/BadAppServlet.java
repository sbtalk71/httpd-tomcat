package com.demo.appserver;

import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Date;
import javax.servlet.*;
import javax.servlet.http.*;

public class BadAppServlet extends HttpServlet {
	private class A {

		public B b;
		public C c;
		final BadAppServlet this$0;

		A() {
			super();
			this$0 = BadAppServlet.this;

		}
	}

	private class B {

		public D d;
		public E e;
		final BadAppServlet this$0;

		B() {
			super();
			this$0 = BadAppServlet.this;

		}
	}

	private class C {

		public F f;
		public G g;
		final BadAppServlet this$0;

		C() {
			super();
			this$0 = BadAppServlet.this;

		}
	}

	private class D {

		private byte fiveMegBlock[];
		final BadAppServlet this$0;

		D() {
			super();
			this$0 = BadAppServlet.this;

			fiveMegBlock = new byte[0x4e2000];
		}
	}

	private class E {

		final BadAppServlet this$0;

		E() {
			super();
			this$0 = BadAppServlet.this;

		}
	}

	private class F {

		private byte oneMegBlock[];
		final BadAppServlet this$0;

		F() {
			super();
			this$0 = BadAppServlet.this;

			oneMegBlock = new byte[0xfa000];
		}
	}

	private class G {

		final BadAppServlet this$0;

		G() {
			super();
			this$0 = BadAppServlet.this;

		}
	}

	private static final long serialVersionUID = 1L;
	protected int badBehaviorMode;
	private static final String STATUS = "STATUS";
	private boolean isFirstUserOfDeadlockingPair;
	private Object deadlockFirstResource;
	private Object deadlockSecondResource;
	private static ArrayList inUseObjects = new ArrayList();
	private int memoryUsedPerMinute;

	public BadAppServlet() {
		badBehaviorMode = 0;
		isFirstUserOfDeadlockingPair = true;
		deadlockFirstResource = new Object();
		deadlockSecondResource = new Object();
	}

	public void init() throws ServletException {
		String memProperty = System.getProperty(
				"com.ibm.issf.atjolin.badapp.memoryUsedPerMinute", "35");
		memoryUsedPerMinute = Integer.parseInt(memProperty);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String statusMsg = "Beginning a new request";
		badBehaviorMode = Integer.parseInt(request.getParameter("mode"));
		try {
			System.out.println("BadApp: Parameters passed from the user:");
			System.out.println((new StringBuilder(
					"BadApp: Parameter 'badBehaviorMode' = ")).append(
					badBehaviorMode).toString());
			switch (badBehaviorMode) {
			case 1: // '\001'
				if (isFirstUserOfDeadlockingPair) {
					isFirstUserOfDeadlockingPair = false;
					dopeyMethod();
				} else {
					sneezyMethod();
					isFirstUserOfDeadlockingPair = true;
				}
				statusMsg = "User should never see this status text, in this mode BadApp should not return a "
						+ "response.";
				break;

			case 2: // '\002'
				sleepyMethod();
				statusMsg = "A BadApp request in mode 2 has completed.";
				break;

			case 3: // '\003'
				happyMethod();
				statusMsg = "A BadApp request in mode 3 has completed.";
				break;

			case 4: // '\004'
				docMethod(5);
				statusMsg = "A BadApp request in mode 4 has completed.";
				break;

			case 5: // '\005'
				docMethod(1000);
				statusMsg = "A BadApp request in mode 5 has completed (although you should never see this res"
						+ "ponse).";
				break;

			default:
				statusMsg = "You entered an invalid value for Bad Behavior Mode, please try again.";
				break;
			}
		} catch (Throwable e) {
			if (e instanceof OutOfMemoryError) {
				System.out
						.println("BadApp: hit an OutOfMemoryError (maybe as expected)");
				statusMsg = "OutOfMemoryException was thrown (was this expected?), see WAS logs";
			} else {
				System.err.println((new StringBuilder(
						"BadApp: Whoops! Caught an exception: ")).append(e)
						.toString());
				statusMsg = (new StringBuilder(
						"BadApp: Whoops! Caught an exception: ")).append(e)
						.toString();
			}
			e.printStackTrace();
		}
		request.setAttribute("STATUS", statusMsg);
		RequestDispatcher dispatcher = getServletContext()
				.getRequestDispatcher("/BadAppJSP.jsp");
		dispatcher.forward(request, response);
	}

	public void dopeyMethod() {
		synchronized (deadlockFirstResource) {
			try {
				Thread.sleep(30000L);
			} catch (InterruptedException interruptedexception) {
			}
			synchronized (deadlockSecondResource) {
				System.out
						.println("BadApp: firstDeadlockingMethod is able to lock 2nd resource - and thus complete.");
			}
		}
		System.out
				.println("BadApp: firstDeadlockMethod has unlocked both resources and is completing.");
	}

	public void sneezyMethod() {
		synchronized (deadlockSecondResource) {
			try {
				Thread.sleep(30000L);
			} catch (InterruptedException interruptedexception) {
			}
			synchronized (deadlockFirstResource) {
				System.out
						.println("BadApp: secondDeadlockingMethod is able to lock 1st resource - and thus complete"
								+ ".");
			}
		}
		System.out
				.println("BadApp: secondDeadlockMethod has unlocked both resources and is completing.");
	}

	public synchronized void sleepyMethod() {
		try {
			Thread.sleep(10000L);
		} catch (InterruptedException interruptedexception) {
		}
		System.out
				.println("BadApp: lockContentionMethodWithSynch is completing and will unlock its resource"
						+ " on return.");
	}

	public void happyMethod() {
		try {
			Thread.sleep(10000L);
		} catch (InterruptedException interruptedexception) {
		}
		System.out
				.println("BadApp: lockContentionMethodWithSynch is completing and will unlock its resource"
						+ " on return.");
	}

	public void docMethod(int outerLoopCount) throws OutOfMemoryError {
		long numberOfMinutesSinceWeStarted = 0L;
		long start = (new Date()).getTime();
		for (long now = (new Date()).getTime(); now < start + 10000L; now = (new Date())
				.getTime()) {
			try {
				Thread.sleep(2000L);
			} catch (InterruptedException interruptedexception) {
			}
		}

		for (int i = 0; i < outerLoopCount; i++) {
			long minuteLoopStart = (new Date()).getTime();
			for (int j = 0; j < memoryUsedPerMinute; j++) {
				A anA = new A();
				anA.b = new B();
				anA.c = new C();
				anA.b.d = new D();
				anA.b.e = new E();
				anA.c.f = new F();
				anA.c.g = new G();
				inUseObjects.add(anA.c);
			}

			long now;
			for (now = (new Date()).getTime(); now < minuteLoopStart + 60000L; now = (new Date())
					.getTime()) {
				try {
					Thread.sleep(2000L);
				} catch (InterruptedException interruptedexception1) {
				}
			}

			numberOfMinutesSinceWeStarted = (now - start) / 60000L;
			System.out.println((new StringBuilder(
					"BadApp: Request has been running for "))
					.append(numberOfMinutesSinceWeStarted).append(" minutes.")
					.toString());
		}

	}

}
